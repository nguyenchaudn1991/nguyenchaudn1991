---
name: jp-requirement
description: >-
  Use when handling requirements for Japanese clients: (1) phân tích yêu cầu /
  要件分析 / 要件整理 / nghiên cứu giải pháp / đề xuất phương án — from any source
  (pptx, .md, html, Figma, Backlog notes); (2) viết 要件定義書 / requirement
  definition document; (3) dịch & "nhai nhỏ" spec Nhật cho team dev VN — 仕様書,
  dịch spec, spec breakdown. Do NOT trigger for: 工数見積 / estimates and 議事録
  (company process, owned by another role); situation-based client communication —
  障害報告/催促/納期交渉/謝罪/依頼, Q&A管理, 週次報告 (→ skill jp-comm).
allowed-tools: Bash, Read, Write, Edit, AskUserQuestion, Skill
---

# JP Requirement — phân tích yêu cầu → 要件定義書 → spec cho dev

Pipeline yêu cầu cho công việc DM/BrSE với khách Nhật cấp cao, không sâu kỹ thuật:
nhận yêu cầu mọi định dạng → phân tích + đề xuất options → chốt thành 要件定義書 →
nhai nhỏ cho team dev VN.

## Routing

| Việc | File PHẢI load |
|---|---|
| Phân tích yêu cầu / nghiên cứu giải pháp / đề xuất phương án + trade-off | [references/requirement-analysis.md](references/requirement-analysis.md) |
| Viết / review 要件定義書 | [references/yoken-teigi.md](references/yoken-teigi.md) |
| Dịch & nhai nhỏ spec Nhật cho dev VN | [references/spec-breakdown.md](references/spec-breakdown.md) |

Không load file không cần. Giao tiếp tình huống (báo bug, nhắc, deadline…), bảng Q&A,
báo cáo tuần → skill `jp-comm`. Trình bày kết quả thành deck 技術検討会 → skill
`meo-pptx`; thành trang web report → skill `premium-web` (type report).

## Nguyên tắc cốt lõi

1. **結論ファースト.** Kết luận/đề xuất/điều cần khách quyết đứng đầu tài liệu.
2. **Mọi khẳng định có căn cứ.** Số liệu + nguồn + điều kiện đo; chưa xác nhận →
   `未確認`/`調査中`/`〜と想定` — **cấm đoán rồi trình bày như sự thật**.
3. **Mọi giả định nói to:** liệt kê ở mục 前提 kèm câu hỏi xác nhận dạng A/B.
   Giả định ngầm là nguồn số 1 của làm-lại.
4. **Không bao giờ 1 phương án duy nhất:** ≥ 2 options + メリット/デメリット từng cái +
   推奨 kèm lý do. Khách quyết, mình tư vấn.
5. **Không đưa 工数/estimate** khi chưa bàn team — 規模感 chỉ ở mức 大/中/小,
   ghi 「工数・スケジュールは別途ご提示します」.
6. **Viết cho khách 納得:** analogy/ví dụ trước, jargon sau (kèm giải thích 1 dòng);
   chi tiết kỹ thuật xuống 補足.
7. **Mirror vocabulary:** dùng đúng thuật ngữ trong tài liệu khách gửi, không tự đổi từ.
8. **Số liệu soát chéo lượt cuối** trước khi gửi — 1 số sai = mất 信頼 cả tài liệu.

## Common mistakes

| Sai lầm | Sửa |
|---------|-----|
| Trình bày 1 phương án "tốt nhất" | ≥ 2 options + bảng trade-off, khách chọn |
| Đoán chỗ thiếu thông tin rồi làm tiếp | Ghi 前提 tạm + câu hỏi A/B; việc vẫn chạy, kết luận đánh dấu ※前提 |
| Kèm man-day cho từng option | Chỉ 規模感 大/中/小; 工数 chờ bàn team |
| Viết yêu cầu bằng từ mơ hồ (など・適宜…) | Bảng bẫy trong spec-breakdown.md áp cho cả chiều mình viết |
| 要件定義書 sửa im lặng sau khi khách 承認 | Mọi thay đổi qua 変更管理: version + 変更前→変更後 + lý do |
| Dịch spec word-by-word cho dev | Dịch ý + DoD từng mục + đánh dấu ※判断 chỗ mình phán đoán |
