---
name: mobile-first-performance
description: >-
  Achieve Lighthouse 90+ on mobile (Core Web Vitals: LCP < 2.5s, CLS < 0.1, INP < 200ms).
  Next.js focused. iOS-first testing (iPhone SE 2nd gen, iPhone 14+). Image optimization, 
  font strategy, render-blocking resources, animation performance. Triggers on: pagespeed 
  audit, lighthouse score, performance optimization, mobile performance, CLS issue, LCP slow.
---

# Mobile-First Performance — Lighthouse 90+

Build websites that **load fast on mobile** and pass Core Web Vitals targets, especially on 
real devices (not just lab conditions).

> This skill targets **Lighthouse 90+** on mobile, assuming your image pipeline 
> (Sharp → WebP + optimization) and upload system are already in place.
> 
> **Design choices are not covered here.** That's the premium-design skill.
> This focuses purely on performance metrics and testing workflow.

---

## When to Use This Skill

✅ Use this when:
- Running Lighthouse and score is below 90
- Checking LCP, CLS, or INP metrics before shipping
- Optimizing images, fonts, or script loading
- Debugging performance issues on real iOS devices
- Setting up performance testing workflow
- Refactoring for mobile-first delivery

❌ Do NOT use this for:
- Design decisions (use premium-design skill)
- SEO technical audit (separate skill)
- Backend/API optimization (out of scope)
- Database query optimization (not web vitals)

---

## Non-negotiable Rules

1. **Mobile-first testing, not desktop-first.** Always test on iPhone SE 2nd gen or Moto G4 first. 
   Desktop scores are meaningless if mobile fails.

2. **Measure on real devices, not just lab.** Lab (Lighthouse) ≠ Field (real users on 4G/WiFi). 
   Both matter, but field data is truth.

3. **LCP must be < 2.5s on 4G throttle.** This is the hard target. Anything slower, and 90+ is impossible.

4. **CLS < 0.1 is non-negotiable.** Avoid layout shifts from unoptimized images, fonts, or dynamic content.

5. **All images must be Next.js `<Image>` component or equivalent.** 
   No `<img>` tags with `src="huge-file.jpg"`. Images are the #1 LCP killer.

6. **Critical fonts must be preloaded.** 2 font files maximum in the critical path. 
   Anything else is lazy-loaded.

7. **No render-blocking JS above the fold.** Async, defer, or move below-fold content to separate bundle.

---

## Core Web Vitals Targets

| Metric | Target | Threshold |
|--------|--------|-----------|
| **LCP** (Largest Contentful Paint) | < 2.5s | Good |
| **INP** (Interaction to Next Paint) | < 200ms | Good |
| **CLS** (Cumulative Layout Shift) | < 0.1 | Good |
| **Lighthouse Score** | 90+ | (composite) |

---

## Image Optimization Pipeline

You have Sharp + WebP conversion in place. Here's how to ship it correctly.

### 1. Use `next/image` Component (Not `<img>`)

**Bad:**
```jsx
<img src="/images/hero.jpg" alt="Hero" />
```

**Good:**
```jsx
import Image from 'next/image';

<Image
  src="/images/hero.jpg"
  alt="Hero"
  width={1200}
  height={600}
  priority // Use only for above-fold images (LCP candidates)
  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 90vw, 1200px"
/>
```

### 2. Responsive Sizes Attribute

**Why:** Tells Next.js which image size to load based on viewport. Without it, desktop image loads on mobile = wasted bandwidth.

```jsx
sizes="(max-width: 640px) 100vw,    // Full width on mobile
       (max-width: 1024px) 90vw,   // 90% width on tablet
       1200px"                       // 1200px on desktop
```

### 3. Set `priority` Only for LCP Candidates

- Hero image above the fold → `priority`
- Image below the fold → remove `priority` (default lazy-loads)
- Thumbnail grids → no priority

### 4. Image Format Waterfall

Next.js Image Optimization handles this automatically, but verify:

1. Serve **WebP** on modern browsers (Chrome, Firefox, Safari 16+)
2. Fallback to **JPEG** on older browsers
3. File size budget: images should total < 200KB for hero section

### 5. Acceptable Image File Sizes

After optimization (Sharp pipeline):
- Hero image (1200x600): max 80KB (WebP), 120KB (JPEG)
- Thumbnail (400x300): max 20KB
- Full-width section (1920x1080): max 150KB

If files exceed these, re-compress or reduce dimensions.

---

## Font Loading Strategy

Fonts are the #2 LCP killer after images. Use Next.js `next/font` for automatic optimization.

### 1. Load Fonts via `next/font`

**Best (built-in optimization):**
```jsx
// app/layout.jsx
import { Be_Vietnam_Pro, Noto_Sans_JP } from 'next/font/google';

const beVietnam = Be_Vietnam_Pro({
  subsets: ['latin', 'vietnamese'],
  weight: ['400', '500', '600', '700'],
  display: 'swap', // Don't wait for font; swap when ready
  fallback: ['system-ui', 'sans-serif'],
});

const notoSansJP = Noto_Sans_JP({
  subsets: ['latin', 'cyrillic'], // Note: JP subset includes Latin
  weight: ['400', '500', '700'],
  display: 'swap',
});

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${beVietnam.className} ${notoSansJP.className}`}>
      {children}
    </html>
  );
}
```

### 2. Font-Family Fallback Stack

**Vietnamese:**
```css
font-family: 'Be Vietnam Pro', 'Plus Jakarta Sans', system-ui, sans-serif;
```

**Japanese:**
```css
font-family: 'Noto Sans JP', 'Hiragino Sans', 'Yu Gothic', system-ui, sans-serif;
```

### 3. Critical Font Weights Only

- Load: `400` (regular), `600` (semibold), `700` (bold)
- Do NOT load: `300`, `500`, `800`, `900` unless used
- Each weight = separate HTTP request = slower

### 4. Font Subsetting

Google Fonts' `subsets` parameter reduces font file size:

```jsx
// Load Latin + Vietnamese only (not Thai, Greek, etc)
const beVietnam = Be_Vietnam_Pro({
  subsets: ['latin', 'vietnamese'],
  weight: ['400', '600', '700'],
});

// Japanese: must include Latin for labels/UI text
const noto = Noto_Sans_JP({
  subsets: ['latin', 'cyrillic'], // cyrillic not needed, but Latin is
  weight: ['400', '700'],
});
```

### 5. What NOT to Do

- ❌ `@import 'https://fonts.googleapis.com/...'` in CSS (render-blocking)
- ❌ Load 10+ font weights
- ❌ Load fonts synchronously via `<link rel="stylesheet">`
- ❌ Use local font files without `font-display: swap`

---

## Render-Blocking Resources

Anything that delays first paint of the page.

### 1. Critical CSS (Above-the-Fold Only)

- Inline CSS for header/nav/hero section (< 14KB gzipped)
- Defer non-critical CSS to separate file or async load

**With Next.js + Tailwind:** This is usually automatic. If CSS file > 50KB, check for unused classes.

```bash
# Audit Tailwind CSS output size
npx tailwindcss build styles.css --minify | wc -c
```

If > 50KB → run PurgeCSS or verify Tailwind config is correct.

### 2. Async JavaScript

**Bad (blocks render):**
```html
<script src="/js/analytics.js"></script>
```

**Good:**
```html
<script async src="/js/analytics.js"></script>
```

### 3. Third-Party Scripts

Move low-priority scripts to `<body>` end or load with `defer`:

```jsx
// app/layout.jsx
export default function RootLayout({ children }) {
  return (
    <html>
      <head>
        {/* Async non-critical JS */}
        <script async src="https://cdn.example.com/analytics.js" />
      </head>
      <body>{children}</body>
    </html>
  );
}
```

### 4. Web Fonts Load Strategy

Already covered in Font Loading section. Use `next/font` with `display: swap`.

---

## Mobile-Specific Issues

### 1. Viewport Meta Tag

**Required in all Next.js apps (add to `<head>` if missing):**
```html
<meta name="viewport" content="width=device-width, initial-scale=1" />
```

### 2. iOS Safe Area

Devices with notch (iPhone 12+) need safe-area padding:

```css
/* Respect safe areas on iPhone with notch */
body {
  padding-top: max(20px, env(safe-area-inset-top));
  padding-bottom: max(20px, env(safe-area-inset-bottom));
}

/* For full-width header */
header {
  padding-top: env(safe-area-inset-top);
}
```

### 3. Fixed Headers and CLS

**Problem:** Fixed header causes content to shift under it = CLS penalty.

**Fix:**
```css
/* Add padding-top to body to account for fixed header */
body {
  padding-top: 60px; /* height of fixed header */
}

header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 60px;
  z-index: 100;
}
```

### 4. 100vh on Mobile = Bad

**Problem:** iOS Safari treats `100vh` as the full viewport (including address bar), causing content overflow.

**Fix:**
```css
/* Use 100dvh (dynamic viewport height) instead */
.hero {
  min-height: 100dvh; /* Not height: 100vh */
}
```

### 5. Tap Target Size (WCAG)

**Minimum:** 44x44px for tap targets (buttons, links).

**Bad:**
```jsx
<button style={{ padding: '6px 12px' }}>Small Button</button>
```

**Good:**
```jsx
<button style={{ padding: '12px 16px' }}>Better</button>
```

### 6. Touch-Friendly Spacing

On mobile, increase padding/margin:
- Buttons: 12px padding (not 8px)
- Links: 8px padding around text
- Form inputs: 44px height (not 32px)

### 7. Prevent Zoom on Input Focus

iOS zooms in when focused on input < 16px. Set font-size to 16px or larger:

```css
input {
  font-size: 16px; /* Prevents iOS zoom-on-focus */
}
```

### 8. Orientation Changes (Landscape/Portrait)

Changing orientation causes layout shift = CLS penalty. Test both.

Use media queries to adapt:
```css
@media (orientation: landscape) {
  .hero {
    min-height: auto; /* Shorter on landscape */
  }
}
```

---

## Animation Performance

Animations kill INP and CLS if done wrong.

### 1. Use `transform` and `opacity` Only

**GPU-accelerated (good for performance):**
```css
@keyframes slide {
  from { transform: translateX(-100px); }
  to { transform: translateX(0); }
}

.card:hover {
  opacity: 0.9;
  transform: scale(1.02);
}
```

**Layout-thrashing (bad):**
```css
/* AVOID */
@keyframes slide {
  from { left: -100px; } /* Triggers reflow */
  to { left: 0; }
}
```

### 2. Spring Physics (Cautiously)

Spring-based easing (bouncy animations) is nice but causes CLS if not careful.

**Safe approach:**
- Use spring on `transform` only (not on width/height/left/top)
- Test INP/CLS after adding springs
- If INP > 200ms, reduce spring intensity or remove

**Example (with Framer Motion):**
```jsx
<motion.div
  animate={{ x: 0 }}
  transition={{ type: 'spring', stiffness: 100, damping: 10 }}
/>
```

### 3. Parallax and Scroll Animations

Scroll-driven animations can cause INP spikes if main thread is blocked.

**Safe approach:**
- Use `will-change: transform` to hint GPU acceleration
- Throttle scroll event listeners (max 60fps)
- Test on iPhone SE 2nd gen (older device = slower)

```css
.parallax {
  will-change: transform;
}
```

### 4. No Animation During Page Load

Avoid animations until after LCP. Use CSS `animation-delay` or JS to defer:

```jsx
// Delay animation until after LCP
setTimeout(() => {
  document.querySelector('.hero').classList.add('animate-in');
}, 2500); // After LCP target
```

---

## Caching Strategy

### 1. Cache-Control Headers

Set in `next.config.js` or via your hosting provider:

```javascript
// next.config.js
module.exports = {
  headers: async () => [
    {
      source: '/(.*)',
      headers: [
        {
          key: 'Cache-Control',
          value: 'public, max-age=3600, s-maxage=86400, stale-while-revalidate=604800',
        },
      ],
    },
    {
      source: '/api/(.*)',
      headers: [
        {
          key: 'Cache-Control',
          value: 'public, max-age=60, s-maxage=300',
        },
      ],
    },
  ],
};
```

### 2. Static Generation (Recommended)

Use `getStaticProps` or Incremental Static Revalidation (ISR):

```jsx
// app/page.jsx (Next.js 13+ App Router)
export const revalidate = 3600; // Revalidate every hour

export default async function Home() {
  const data = await fetch('https://api.example.com/data');
  return <div>{data}</div>;
}
```

### 3. Service Worker (Optional)

For offline support and faster repeat visits:

```javascript
// public/sw.js (basic service worker)
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open('v1').then((cache) => {
    return cache.addAll(['/']);
  }));
});

self.addEventListener('fetch', (e) => {
  e.respondWith(caches.match(e.request).then((r) => r || fetch(e.request)));
});
```

---

## Performance Testing Workflow

### 1. Lab Testing (Lighthouse)

```bash
# Run Lighthouse from CLI
npm install -g @lhci/cli@latest
lhci autorun --config=lighthouserc.json
```

**lighthouserc.json:**
```json
{
  "ci": {
    "collect": {
      "url": ["http://localhost:3000"],
      "numberOfRuns": 3
    },
    "assert": {
      "preset": "lighthouse:recommended",
      "assertions": {
        "categories:performance": ["error", { "minScore": 0.90 }],
        "largest-contentful-paint": ["error", { "maxNumericValue": 2500 }],
        "cumulative-layout-shift": ["error", { "maxNumericValue": 0.1 }]
      }
    }
  }
}
```

### 2. Mobile Device Testing

**Minimum test devices:**
- iPhone SE 2nd gen (2020) — budget device, slow 4G
- iPhone 14+ — modern device, fast connection

**Testing procedure:**
1. Connect device to same WiFi as dev machine
2. Open DevTools → Remote Debugging (Chrome) or Safari Inspector (iOS)
3. Network tab: throttle to "Slow 4G"
4. Load page, measure LCP/INP/CLS visually
5. Check Chrome DevTools → Performance tab for bottlenecks

### 3. Field Data (CrUX)

Google Chrome User Experience Report shows real user data:

1. Deploy site to production
2. Wait 28 days for data to accumulate
3. Check `https://cruxdashboard.appspot.com/`

Field data > lab data. If field CLS is high but lab is low, you have a real issue on certain devices.

### 4. Continuous Monitoring

Set up Lighthouse CI on GitHub Actions:

```yaml
# .github/workflows/lighthouse.yml
name: Lighthouse CI

on: [push, pull_request]

jobs:
  lighthouse:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run build
      - run: npx @lhci/cli@0.9.x autorun
```

---

## Debugging Performance Issues

### Problem: LCP > 2.5s

**Common causes:**
1. Hero image not optimized (> 100KB)
2. Font loading blocks rendering
3. Third-party scripts render-blocking
4. Server response slow (TTFB > 600ms)

**Debug steps:**
```javascript
// Log LCP in browser console
new PerformanceObserver((list) => {
  list.getEntries().forEach((entry) => {
    console.log('LCP:', entry.renderTime || entry.loadTime);
    console.log('LCP element:', entry.element);
  });
}).observe({ type: 'largest-contentful-paint', buffered: true });
```

**Fix:**
- [ ] Check hero image size (should be WebP, < 80KB)
- [ ] Ensure `priority` on LCP image in `next/image`
- [ ] Defer non-critical scripts (analytics, chat widget)
- [ ] Check TTFB (should be < 600ms) — if slow, it's a server issue

### Problem: CLS > 0.1

**Common causes:**
1. Images without dimensions (width/height)
2. Fonts loading and changing layout
3. Fixed header pushing content down
4. Ads/dynamic content loaded above fold

**Debug steps:**
```javascript
// Log CLS contributors
new PerformanceObserver((list) => {
  list.getEntries().forEach((entry) => {
    if (!entry.hadRecentInput) {
      console.log('CLS:', entry.value);
      console.log('Shifted element:', entry.sources[0].node);
    }
  });
}).observe({ type: 'layout-shift', buffered: true });
```

**Fix:**
- [ ] All images have width/height props
- [ ] Fonts use `display: swap` (or already loaded)
- [ ] Fixed header has body padding-top
- [ ] Form inputs don't resize on focus

### Problem: INP > 200ms

**Common causes:**
1. JavaScript executing during user interaction
2. Long tasks (> 50ms) blocking main thread
3. Too many event listeners

**Debug steps:**
```javascript
// Log slow interactions (INP candidates)
new PerformanceObserver((list) => {
  list.getEntries().forEach((entry) => {
    if (entry.duration > 200) {
      console.log('Slow interaction (INP):', entry.duration, 'ms');
      console.log('Event type:', entry.name);
    }
  });
}).observe({ type: 'event', durationThreshold: 100, buffered: true });
```

**Fix:**
- [ ] Defer heavy JS computations to Web Worker
- [ ] Break long tasks into chunks with `setTimeout`
- [ ] Lazy-load non-critical features (modals, plugins)

---

## Checklist Before Shipping

- [ ] Lighthouse 90+ on mobile (3 runs average)
- [ ] LCP < 2.5s on 4G throttle (iPhone SE 2nd gen)
- [ ] CLS < 0.1 (no layout shifts visible)
- [ ] INP < 200ms (interactions respond quickly)
- [ ] All images use `next/image` with `sizes`
- [ ] Critical fonts preloaded, non-critical deferred
- [ ] No render-blocking JS above fold
- [ ] No console errors or warnings
- [ ] Tested on real iOS device (iPhone SE or iPhone 14)
- [ ] Tested on real Android device (Moto G4 or similar)
- [ ] Orientations tested (landscape, portrait)
- [ ] Cache headers set correctly
- [ ] Form inputs 44px+ height (prevent zoom on iOS)
- [ ] Safe areas respected (notch devices)

---

## Rules

- Do NOT compromise on mobile. If it's not fast on iPhone SE 2nd gen, it's not fast.
- Measure on real devices, not just Lighthouse.
- Defer all non-critical JS and CSS.
- Every image must be lazy-loaded unless it's LCP candidate.
- Fonts are as important as images for performance. Optimize first.
- Spring physics and parallax are nice, but measure INP/CLS after adding them.

---

## Field Notes — lessons from real client projects

> Verified on production work (topdoanhnghiep.com, Cloudflare Workers SSR, 06/2026).
> This skill is Next.js-focused; these notes cover the no-framework / SSR-HTML case
> and PSI findings that the sections above don't mention explicitly.

### LCP: CSS background-image heroes

- A hero set via CSS `background-image` is discovered late (after CSS parse) and PSI
  flags it. Fix with **both**: `<link rel="preload" as="image" href="..."
  fetchpriority="high">` in `<head>`, and a `media` attribute per breakpoint when
  desktop/mobile use different files:
  `media="(min-width: 641px)"` for `hero.webp`, `media="(max-width: 640px)"` for `hero_sp.webp`.
  PSI specifically flags a preload **without** `fetchpriority=high` — the preload alone
  is not enough to clear the audit.
- Serve a separate portrait mobile hero (`_sp` file, ~1/4 the bytes) selected by the
  same media query in CSS. Mobile must never download the desktop hero.

### Caching: replace-in-place assets

- `max-age=31536000, immutable` is only safe for hashed/timestamped filenames.
  If the client replaces `hero.webp` **keeping the same filename** (the usual
  non-technical workflow), immutable caching shows the old image for a year.
  Use `max-age=86400, stale-while-revalidate=604800` for fixed-name assets, and
  reserve 1-year immutable for upload keys containing a timestamp.

### No-framework stacks (no Sharp, no next/image)

- On edge runtimes (Cloudflare Workers) you can't run Sharp. Compress in the admin
  browser instead: `createImageBitmap` → canvas → `canvas.toBlob('image/webp', 0.82)`
  with a max-width resize (1200px), then upload the result. A 5MB phone photo becomes
  ~100KB before it ever leaves the client's machine.
- Zero client-side JS on public pages is the single biggest INP/TBT advantage an
  SSR-HTML site has. Treat any new `<script>` on a public page as a regression that
  needs justification.

### Mobile layout vs performance overlaps

- A header that wraps to 2–3 rows on mobile must NOT be `position: sticky` — it
  permanently covers half the viewport while scrolling. Make it static under ~640px.
- Font fallback choice is a CLS *and* correctness issue: with `display: swap`, pick a
  same-family system fallback that supports the page language (Vietnamese: serif
  fallback must be "Times New Roman", NOT Georgia — Georgia breaks tone marks during
  the swap window).

### Process

- Keep a per-project `PAGESPEED.md` checklist (LCP/CLS/INP/contrast/cache/SEO/mobile)
  and require a pass before any UI commit. Rule that makes it stick: any new PSI
  finding gets fixed AND added as a new checklist item in the same commit.
- PSI contrast audits fail decorative-but-textual elements people forget: rank
  numbers, star ratings, badge text. Saturated accents (gold, light blues) on white
  are the usual offenders — check them at webaim.org before shipping a palette.
