---
name: jp-client
description: >-
  Use when analyzing customer requirements for Japanese clients from any source
  (pptx, .md, html, Figma, Backlog notes) — keywords: "phân tích yêu cầu",
  要件分析, 要件整理, "khách gửi yêu cầu", "nghiên cứu giải pháp", "đề xuất phương án",
  課題分析 — or when writing Japanese business communication for these situations:
  障害報告 / báo bug cho khách, 催促 / nhắc khách chưa trả lời, 納期交渉 / thương lượng
  deadline, 謝罪 / xin lỗi sự cố, 依頼 / nhờ khách làm việc gì. Do NOT trigger for:
  議事録 (owned by someone else), effort estimates / 工数見積 (requires team discussion),
  or building final deliverables (deck → meo-pptx skill, web report → premium-web skill).
allowed-tools: Bash, Read, Write, Edit, AskUserQuestion, Skill
---

# JP Client — phân tích yêu cầu & giao tiếp chuẩn manner với khách Nhật

Skill cho công việc DM/BrSE với khách Nhật **cấp cao**: nhận yêu cầu ở mọi định dạng →
phân tích → nghiên cứu giải pháp → đề xuất options kèm trade-off; và soạn giao tiếp
tiếng Nhật theo đúng khung từng tình huống.

## Routing

| Việc | File PHẢI load |
|---|---|
| Phân tích yêu cầu / nghiên cứu giải pháp / đề xuất phương án | [references/requirement-analysis.md](references/requirement-analysis.md) |
| Soạn giao tiếp theo tình huống (障害報告 · 催促 · 納期交渉 · 謝罪 · 依頼) | [references/situations.md](references/situations.md) |

Không load file không cần. Cần trình bày kết quả phân tích thành deliverable →
chuyển giao: deck 技術検討会 = skill `meo-pptx`; trang web report = skill `premium-web`
(type report). Skill này dừng ở **nội dung và cấu trúc**.

## Nguyên tắc cốt lõi (audience = quản lý cấp cao Nhật, không sâu kỹ thuật)

1. **結論ファースト.** Kết luận/đề xuất/điều cần khách quyết định đứng đầu; giải trình theo sau.
2. **Mọi khẳng định phải có căn cứ.** Số liệu, nguồn, điều kiện đo đi kèm. Chưa xác nhận
   được → ghi rõ `未確認` / `調査中` / `〜と想定` — **cấm đoán rồi trình bày như sự thật**.
   Với khách cấp cao, 1 số liệu sai = mất 信頼 toàn bộ tài liệu.
3. **Số liệu phải tự kiểm tra chéo trước khi gửi:** đơn vị, mốc thời gian, tổng cộng khớp
   từng dòng, nhất quán giữa các chỗ xuất hiện. Đọc lại toàn bộ 1 lần cuối chỉ để soát số.
4. **Giải thích để khách 納得, không phải để khoe kỹ thuật.** Ưu tiên ví dụ đời thường /
   analogy / hình ảnh so sánh trước, thuật ngữ sau (kèm giải thích 1 dòng khi buộc phải dùng).
   Chi tiết kỹ thuật sâu → đẩy xuống phụ lục (補足), thân bài giữ mạch dễ hiểu.
5. **Không bao giờ đề xuất 1 phương án duy nhất.** Tối thiểu 2 options + trade-off
   (メリット/デメリット) từng cái + 推奨 kèm lý do. Khách quyết, mình tư vấn.
6. **Không đưa 工数/estimate** khi chưa bàn với team — ghi `工数・スケジュールは別途ご提示します`.
7. **Ngôn ngữ đầu ra:** tiếng Nhật です・ます調, không dấu chấm than, không emoji;
   dùng đúng thuật ngữ khách đã dùng trong tài liệu của họ (mirror vocabulary, không tự đổi từ).
8. **Mọi giả định phải nói to.** Phân tích dựa trên giả định nào → liệt kê ở mục 前提,
   kèm câu hỏi xác nhận. Giả định ngầm là nguồn số 1 của làm-lại.

## Common mistakes

| Sai lầm | Sửa |
|---------|-----|
| Trình bày 1 phương án "tốt nhất" | Luôn ≥ 2 options + bảng trade-off, khách chọn |
| Viết cho kỹ sư đọc | Viết cho quản lý: kết luận + con số + ví dụ dễ hiểu; kỹ thuật xuống 補足 |
| Đoán chỗ thiếu thông tin rồi làm tiếp | Ghi 前提 + gửi câu hỏi xác nhận dạng lựa chọn A/B cho khách trả lời nhanh |
| Kèm luôn man-day cho từng option | Chỉ 規模感 tương đối (大/中/小); 工数 chờ bàn team |
| Báo bug khi đã điều tra xong mới báo | 第一報 ngay khi phát hiện, nguyên nhân ghi 調査中 (xem situations.md) |
| Dùng 了解しました với khách | 承知いたしました / かしこまりました (bảng 敬語 trong situations.md) |
