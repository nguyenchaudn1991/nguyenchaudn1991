# Hướng dẫn cài đặt — bộ skill BrSE (jp-comm + jp-requirement)

Bộ 2 skill dùng chung, nên cài **cả hai**:
- **jp-comm** — giao tiếp khách Nhật: 障害報告, 催促, 納期交渉, 謝罪, 依頼, Q&A管理・課題表, 納品報告/リリース連絡/週次報告
- **jp-requirement** — phân tích yêu cầu, viết 要件定義書, dịch & nhai nhỏ spec Nhật cho dev VN

> Lưu ý phạm vi: bộ skill KHÔNG hỗ trợ 議事録 và 工数見積 (theo quy trình công ty, vai trò khác đảm nhận).

## Claude (khuyến nghị — hỗ trợ định dạng skill gốc, chất lượng tốt nhất)

**claude.ai (web/app):**
1. Settings → Capabilities → **Skills** → Upload skill → chọn file zip (upload lần lượt từng zip).
2. Trong chat, skill tự kích hoạt theo từ khóa (VD: "viết 障害報告 về sự cố X", "phân tích yêu cầu trong file pptx này", "dịch spec này cho dev") hoặc gọi đích danh: "dùng skill jp-comm…".

**Claude Code (terminal/IDE):** giải nén zip vào `C:\Users\<user>\.claude\skills\` (mỗi skill 1 folder: `jp-comm`, `jp-requirement`).

## ChatGPT (không có định dạng skill — dùng Projects hoặc Custom GPT)

1. Tạo **Project** (hoặc Custom GPT).
2. Giải nén zip → copy nội dung `SKILL.md` dán vào **Instructions**.
3. Upload các file trong `references/` làm file đính kèm (knowledge).
4. Khi dùng: nêu rõ việc ("viết 週次報告 tuần này theo format trong tài liệu").

## Gemini (Gems)

1. Tạo **Gem** mới.
2. **Instructions** = nội dung `SKILL.md`; đính kèm các file trong `references/`.

## Lưu ý bắt buộc

- **Chính sách dữ liệu:** tuân thủ quy định công ty khi đưa tài liệu khách hàng vào AI tool — chưa rõ tài khoản/plan nào được phép thì hỏi quản lý trước khi dùng.
- **Skill là khung hỗ trợ** — người gửi chịu trách nhiệm review cuối cùng trước khi gửi khách.
- Feedback / đề xuất bổ sung tình huống: gửi về **Châu** (maintainer).
- Phiên bản: **v1.0 (2026-07-11)**.
