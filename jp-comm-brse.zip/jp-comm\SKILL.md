---
name: jp-comm
description: >-
  Use when writing Japanese business communication to clients: (1) situations —
  障害報告 / báo bug cho khách, 催促 / nhắc khách chưa trả lời, 納期交渉 / thương lượng
  deadline, 謝罪 / xin lỗi, 依頼 / nhờ khách; (2) Q&A管理・課題表 — tạo/quản lý bảng
  câu hỏi và issue với khách; (3) báo cáo — 納品報告, リリース連絡, 週次報告 / weekly
  report. Keywords: 敬語, viết mail khách Nhật, soạn tin nhắn khách. Do NOT trigger
  for: 議事録 and 工数見積 (company process, owned by another role); requirement
  analysis / 要件定義 (→ skill jp-requirement).
allowed-tools: Bash, Read, Write, Edit, AskUserQuestion, Skill
---

# JP Comm — giao tiếp chuẩn manner với khách Nhật cấp cao

Soạn giao tiếp tiếng Nhật cho công việc DM/BrSE: đúng khung từng tình huống, đúng mức
敬語, số liệu chuẩn. Đối tượng đọc là **quản lý cấp cao, không sâu kỹ thuật**.

## Routing

| Việc | File PHẢI load |
|---|---|
| Tình huống: 障害報告 · 催促 · 納期交渉 · 謝罪 · 依頼 | [references/situations.md](references/situations.md) |
| Bảng Q&A / 課題表 với khách (tạo, viết câu hỏi, vận hành, đóng) | [references/qa-management.md](references/qa-management.md) |
| 納品報告 · リリース連絡 · 週次報告 | [references/reporting.md](references/reporting.md) |

Không load file không cần. Phân tích yêu cầu / viết 要件定義書 / dịch spec → skill
`jp-requirement`, không phải skill này.

## Nguyên tắc cốt lõi (áp cho mọi văn bản gửi khách)

1. **結論ファースト.** Điều khách cần biết/quyết định đứng đầu.
2. **Mọi khẳng định có căn cứ.** Số liệu kèm nguồn + điều kiện; chưa xác nhận → ghi
   `未確認`/`調査中`, **cấm đoán rồi viết như sự thật**. 1 số sai = mất 信頼 cả văn bản.
3. **Số liệu soát chéo lượt cuối trước khi gửi:** đơn vị, mốc thời gian (JST), tổng khớp
   từng dòng, nhất quán giữa các chỗ xuất hiện (báo cáo = 課題表 = Backlog).
4. **Viết để khách 納得:** ví dụ/analogy trước, thuật ngữ sau (kèm 1 dòng giải thích);
   chi tiết kỹ thuật đẩy xuống cuối hoặc phụ lục.
5. **Tin xấu báo sớm, kèm đối sách.** Thời điểm báo quan trọng hơn nội dung báo.
6. **Ngôn ngữ:** tiếng Nhật です・ます調, không dấu chấm than, không emoji, dùng đúng
   thuật ngữ khách đang dùng.
7. Đề xuất trong giao tiếp (VD 納期交渉) luôn ≥ 2 options + trade-off — khách quyết, mình tư vấn.
8. **Không đưa 工数/estimate** khi chưa bàn team — 「工数は別途ご提示します」.

## Common mistakes

| Sai lầm | Sửa |
|---------|-----|
| Điều tra xong mới báo sự cố | 第一報 ngay khi phát hiện, nguyên nhân 調査中 (situations.md) |
| 了解しました với khách | 承知いたしました (bảng 敬語 trong situations.md) |
| Nhắc khách kiểu trách móc | Impact theo lịch + cushion words, leo thang 3 nấc |
| Xin lỗi kèm bào chữa cùng câu | 謝罪 và nguyên nhân tách mục riêng |
| Số Backlog đưa thẳng vào report | Kiểm tay trước — tracking tool hay lệch thực tế |
| Câu hỏi mở gửi khách cấp cao | Đóng A/B + khuyến nghị sẵn, khách chỉ gật |
